Resep Digital By Essa Muharam

1. Import Database MySQL file ada di folder 'database'
2. Copy folder farmasi ke htdoc (jika lokal), akses lewat localhost/farmasi/user
3. akun login default email: muharam@gmail.com & password: muharam
4. Done