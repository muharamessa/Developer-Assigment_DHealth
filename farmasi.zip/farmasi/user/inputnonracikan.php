<?php 
session_start();

include 'koneksi.php'; 


if(!isset($_SESSION["user"])){
  echo "<script>alert('anda harus login terlebih dahulu');</script>";
   echo "<script>location='login.php';</script>";
   header('location:login.php');
   exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Resep Digital </title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

<?php include "sidebar.php"; ?>


        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Input Resep Non-Racikan</h1>
           <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
          </div>

          <!-- Content Row -->

<form method="post" enctype="multipart/form-data">

    <label>Pilih Obat</label><br>
    <select name="idobat" class="form-control" required>
        <?php $ambil=$koneksi->query("SELECT obatalkes_id,obatalkes_nama,stok FROM obatalkes_m WHERE stok>0 ORDER BY obatalkes_nama asc");
        while($data=$ambil->fetch_assoc()){
        ?>
        <option value="<?php echo $data['obatalkes_id']; ?>"><?php echo $data['obatalkes_nama']; ?> | Stok: <?php echo $data['stok']; ?></option>
        <?php } ?>
    </select><br>

        <label>Pilih Signa</label><br>
    <select name="idsigna" class="form-control" required>
        <?php $ambil=$koneksi->query("SELECT signa_id,signa_nama FROM signa_m ORDER BY signa_nama asc");
        while($data=$ambil->fetch_assoc()){
        ?>
        <option value="<?php echo $data['signa_id']; ?>"><?php echo $data['signa_nama']; ?></option>
        <?php } ?>
    </select><br>
    

    <label>Nama Resep</label><br>   
    <input type="text" name="namaresep" class="form-control" required><br>
    
     <label>Stok</label><br>   
    <input type="number" name="stok" class="form-control" min=1 value="1" required><br>
   	
   	<button class="btn btn-primary" name="save">Simpan</button>
</form>

<?php
if(isset($_POST["save"])){
  $idobat = $_POST["idobat"];
  $idsigna = $_POST["idsigna"]; 
  $namaresep = $_POST["namaresep"];
  $stok = $_POST["stok"];

    $insert=$koneksi->query("INSERT INTO resepnon_racikan (idresepnon_racikan,idobat,idsigna,namaresep,stok,tglbuat)
      VALUES (null,'$idobat','$idsigna','$namaresep','$stok',NOW())");
    
    if($insert){
      $koneksi->query("UPDATE obatalkes_m SET stok=stok-$stok WHERE obatalkes_id='$idobat'");
      echo "<script>alert('data berhasil ditambah, stok obat berkurang');</script>";
      echo "<script>location='nonracikan.php';</script>";
    } else {
      echo "<script>alert('resep gagal ditambahkan');</script>";
       echo "<script>location='inputnonracikan.php';</script>";
    }


  }


?>

<div class="table-responsive" style="margin-top: 3%">
    <table class="table table-striped table-bordered table-hover" id="tbmitra">
                      <thead>
                        <tr>
                            <th>No</th>
                            <th style="text-align: center"><i class="fas fa-key"></i> Kode Obat</th>
                            <th style="text-align: center">Nama Resep</th>
                            <th style="text-align: center">Nama Obat</th>
                            <th style="text-align: center">Signa</th>
                            <th style="text-align: center">Stok</th>
                            <th style="text-align: center">Tanggal Masuk</th>
                            <th style="text-align: right;"><i class="fas fa-cog"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                      include "koneksi.php";
                      $no=1;  
                      $tampil =$koneksi->query("SELECT *,resepnon_racikan.stok as stokresep FROM resepnon_racikan 
                                                INNER JOIN obatalkes_m ON resepnon_racikan.idobat=obatalkes_m.obatalkes_id
                                                INNER JOIN signa_m ON resepnon_racikan.idsigna=signa_m.signa_id
                                                ORDER BY idresepnon_racikan DESC");
                      while($tampilMas=$tampil->fetch_assoc()){
                      ?>
                        <tr>
                         <td><?php echo $no++; ?></td>
                         <td>
                             <?php echo $tampilMas['obatalkes_kode']; ?>
                          </td>
                          <td>
                             <?php echo $tampilMas['namaresep']; ?>
                          </td>
                          <td>
                             <?php echo $tampilMas['obatalkes_nama']; ?>
                          </td>
                          <td>
                             <?php echo $tampilMas['signa_nama']; ?>
                          </td>
                          <td>
                             <?php echo $tampilMas['stokresep']; ?>
                          </td>
                          <td>
                           <i class="fa fa-calendar" style="color: green"></i> <?php echo $tampilMas['tglbuat']; ?>
                          </td>
                          <td>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>

 <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

		                    