<?php 
session_start();

include 'koneksi.php'; 


if(!isset($_SESSION["user"])){
  echo "<script>alert('anda harus login terlebih dahulu');</script>";
   echo "<script>location='login.php';</script>";
   header('location:login.php');
   exit();
}

$idresep=$_GET["id"];
 $tampil1 =$koneksi->query("SELECT *,resepnon_racikan.stok as stokresep FROM resepnon_racikan 
                                                INNER JOIN obatalkes_m ON resepnon_racikan.idobat=obatalkes_m.obatalkes_id
                                                INNER JOIN signa_m ON resepnon_racikan.idsigna=signa_m.signa_id 
                            WHERE resepnon_racikan.idresepnon_racikan='$idresep'");
                      $tampilRacikan=$tampil1->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Resep Digital</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body id="page-top" class="sidebar-toggled">

  <!-- Page Wrapper -->
  <div id="wrapper">

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            
          </div>

    
           
          <!-- Content Row -->
<center><h2>Detail Resep <?php echo $tampilRacikan["namaresep"]; ?></h2></center><br>
<p align="left">Signa : <?php echo $tampilRacikan["signa_nama"]; ?></p>
<p align="left">Stok : <?php echo $tampilRacikan["stok"]; ?></p>
<p align="left">Tanggal Buat : <?php echo $tampilRacikan["tglbuat"]; ?></p>

<div class="table-responsive" style="margin-top: 3%">
    <table class="table table-striped table-bordered table-hover" id="tbmitra">
                      <thead>
                        <tr>
                            <th>No</th>
                            <th style="text-align: center"><i class="fas fa-key"></i> Kode Obat</th>
                            <th style="text-align: center">Nama Obat</th>

                            <th style="text-align: right;"><i class="fas fa-cog"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                      include "koneksi.php";
                      $no=1;  
                      $tampil =$koneksi->query("SELECT *,resepnon_racikan.stok as stokresep FROM resepnon_racikan 
                                                INNER JOIN obatalkes_m ON resepnon_racikan.idobat=obatalkes_m.obatalkes_id
                                                INNER JOIN signa_m ON resepnon_racikan.idsigna=signa_m.signa_id
                                                WHERE resepnon_racikan.idresepnon_racikan='$idresep'
                                                ORDER BY idresepnon_racikan DESC");
                      while($tampilMas=$tampil->fetch_assoc()){
                      ?>
                        <tr>
                         <td><?php echo $no++; ?></td>
                         <td>
                             <?php echo $tampilMas['obatalkes_kode']; ?>
                          </td>
                          <td>
                             <?php echo $tampilMas['obatalkes_nama']; ?>
                          </td>
                          <td>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>


                              <!-- Footer -->
<script>
window.print();
</script>

</body>

</html>

                        