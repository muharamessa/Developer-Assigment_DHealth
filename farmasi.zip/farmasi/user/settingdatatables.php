<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.1/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>

    <script src="assets/dist/js/jquery.min.js"></script>
    <script src="assets/dist/js/bootstrap.min.js"></script>
    <script src="assets/dist/DataTables/datatables.min.js"></script>

<script type="text/javascript">
    $(document).ready( function () {
    $('#tbmitra').DataTable();
} );

    $(document).ready( function () {
    $('#tbreturn').DataTable();
} );



</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbslider').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbmaximus').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbpoinvoice').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tborderdb').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tborderagen').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tborderreseller').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tborderresellerkeep').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbordermarketer').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbprodukpo').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tblistdropship').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbpengiriman').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbongkir').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbkeranjang').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbpendaftaran').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_sisasaldo').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_pembayaran_marketer').DataTable();
} );
</script>
<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_pembayaran_agen').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_pembayaran_reseller').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_pembayaran_db').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_pengiriman').DataTable();
} );
</script>
<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_ongkirmanual').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_price_list').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_katalog').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_listpoartikel').DataTable();
} );
</script>
<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_listpoartikel2').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbkolibri_admin').DataTable();
} );
</script>


<script type="text/javascript">
        $(document).ready( function () {
    $('#tb_listpo_artikel').DataTable();
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbmitraagen').DataTable({
        "pageLength": 25
    });
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbmitrareseller').DataTable({
        "pageLength": 25
    });
} );
</script>

<script type="text/javascript">
        $(document).ready( function () {
    $('#tbmitramarketer').DataTable({
        "pageLength": 25
    });
} );
</script>

